package com.faikturan;

//implemented by the login and create classes
public interface Database_Interface {
	
	public void initialize();
	
}